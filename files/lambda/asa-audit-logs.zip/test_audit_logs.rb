# frozen_string_literal: true

require_relative "lib/audit_logs"

# Make sure to change the instance id
AuditLogs.new().run
